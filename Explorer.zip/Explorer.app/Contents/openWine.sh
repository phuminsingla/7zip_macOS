#!/bin/bash

###### check password
#if [ -e "/Applications/NTFS-ReadWrite.app/Contents/pw.bin" ]
#then
#        CONFIG_PW=`tail -n 1 /Applications/NTFS-ReadWrite.app/Contents/pw.bin`
#        echo "$CONFIG_PW" | sudo -S sntp -sS time.apple.com
#        echo End Programs
#else
#        echo ""
#        echo "***  Not config password Admin          ***"
#        echo "***  Please remove app and new install  ***"
#        echo ""
#fi

#/usr/local/bin/wine $1
/usr/local/bin/wine explorer C:\\